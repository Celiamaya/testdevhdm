export default class SaveTaskDto {
  id: null | number;

  name: string;
}
